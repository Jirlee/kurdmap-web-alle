--
-- PostgreSQL database dump
--

\restrict EPAUHVd6cdIyngCzOwRiTBGNdyj0lhAkEgNnZlj80gjNvwzlRCaseJeFhCOJpFk

-- Dumped from database version 17.10
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_tokens DROP CONSTRAINT IF EXISTS "FK_user_tokens_users_UserId";
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS "FK_user_roles_users_UserId";
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS "FK_user_roles_roles_RoleId";
ALTER TABLE IF EXISTS ONLY public.user_logins DROP CONSTRAINT IF EXISTS "FK_user_logins_users_UserId";
ALTER TABLE IF EXISTS ONLY public.user_claims DROP CONSTRAINT IF EXISTS "FK_user_claims_users_UserId";
ALTER TABLE IF EXISTS ONLY public.role_claims DROP CONSTRAINT IF EXISTS "FK_role_claims_roles_RoleId";
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS "FK_refresh_tokens_users_user_id";
ALTER TABLE IF EXISTS ONLY public.menu_items DROP CONSTRAINT IF EXISTS "FK_menu_items_businesses_BusinessId";
ALTER TABLE IF EXISTS ONLY public.businesses DROP CONSTRAINT IF EXISTS "FK_businesses_users_OwnerId";
ALTER TABLE IF EXISTS ONLY public.businesses DROP CONSTRAINT IF EXISTS "FK_businesses_categories_CategoryId";
ALTER TABLE IF EXISTS ONLY public.business_services DROP CONSTRAINT IF EXISTS "FK_business_services_businesses_BusinessId";
ALTER TABLE IF EXISTS ONLY public.business_images DROP CONSTRAINT IF EXISTS "FK_business_images_businesses_BusinessId";
DROP INDEX IF EXISTS public.ix_refresh_tokens_user_id;
DROP INDEX IF EXISTS public.ix_refresh_tokens_token;
DROP INDEX IF EXISTS public.ix_refresh_tokens_family;
DROP INDEX IF EXISTS public.ix_refresh_tokens_expires_at;
DROP INDEX IF EXISTS public.ix_menu_items_sort;
DROP INDEX IF EXISTS public.ix_cities_slug;
DROP INDEX IF EXISTS public.ix_categories_sort;
DROP INDEX IF EXISTS public.ix_categories_slug;
DROP INDEX IF EXISTS public.ix_businesses_status;
DROP INDEX IF EXISTS public.ix_businesses_slug;
DROP INDEX IF EXISTS public.ix_businesses_owner;
DROP INDEX IF EXISTS public.ix_businesses_city_category;
DROP INDEX IF EXISTS public.ix_business_services_sort;
DROP INDEX IF EXISTS public.ix_business_images_sort;
DROP INDEX IF EXISTS public.ix_advertisements_active_dates;
DROP INDEX IF EXISTS public."UserNameIndex";
DROP INDEX IF EXISTS public."RoleNameIndex";
DROP INDEX IF EXISTS public."IX_user_roles_RoleId";
DROP INDEX IF EXISTS public."IX_user_logins_UserId";
DROP INDEX IF EXISTS public."IX_user_claims_UserId";
DROP INDEX IF EXISTS public."IX_role_claims_RoleId";
DROP INDEX IF EXISTS public."IX_reviews_BusinessId_UserId";
DROP INDEX IF EXISTS public."IX_reviews_BusinessId";
DROP INDEX IF EXISTS public."IX_favorites_UserId";
DROP INDEX IF EXISTS public."IX_favorites_BusinessId_UserId";
DROP INDEX IF EXISTS public."IX_contact_messages_CreatedAt";
DROP INDEX IF EXISTS public."EmailIndex";
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS "PK_users";
ALTER TABLE IF EXISTS ONLY public.user_tokens DROP CONSTRAINT IF EXISTS "PK_user_tokens";
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS "PK_user_roles";
ALTER TABLE IF EXISTS ONLY public.user_logins DROP CONSTRAINT IF EXISTS "PK_user_logins";
ALTER TABLE IF EXISTS ONLY public.user_claims DROP CONSTRAINT IF EXISTS "PK_user_claims";
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS "PK_roles";
ALTER TABLE IF EXISTS ONLY public.role_claims DROP CONSTRAINT IF EXISTS "PK_role_claims";
ALTER TABLE IF EXISTS ONLY public.reviews DROP CONSTRAINT IF EXISTS "PK_reviews";
ALTER TABLE IF EXISTS ONLY public.refresh_tokens DROP CONSTRAINT IF EXISTS "PK_refresh_tokens";
ALTER TABLE IF EXISTS ONLY public.menu_items DROP CONSTRAINT IF EXISTS "PK_menu_items";
ALTER TABLE IF EXISTS ONLY public.favorites DROP CONSTRAINT IF EXISTS "PK_favorites";
ALTER TABLE IF EXISTS ONLY public.contact_messages DROP CONSTRAINT IF EXISTS "PK_contact_messages";
ALTER TABLE IF EXISTS ONLY public.cities DROP CONSTRAINT IF EXISTS "PK_cities";
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS "PK_categories";
ALTER TABLE IF EXISTS ONLY public.businesses DROP CONSTRAINT IF EXISTS "PK_businesses";
ALTER TABLE IF EXISTS ONLY public.business_services DROP CONSTRAINT IF EXISTS "PK_business_services";
ALTER TABLE IF EXISTS ONLY public.business_images DROP CONSTRAINT IF EXISTS "PK_business_images";
ALTER TABLE IF EXISTS ONLY public.advertisements DROP CONSTRAINT IF EXISTS "PK_advertisements";
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_tokens;
DROP TABLE IF EXISTS public.user_roles;
DROP TABLE IF EXISTS public.user_logins;
DROP TABLE IF EXISTS public.user_claims;
DROP TABLE IF EXISTS public.roles;
DROP TABLE IF EXISTS public.role_claims;
DROP TABLE IF EXISTS public.reviews;
DROP TABLE IF EXISTS public.refresh_tokens;
DROP TABLE IF EXISTS public.menu_items;
DROP TABLE IF EXISTS public.favorites;
DROP TABLE IF EXISTS public.contact_messages;
DROP TABLE IF EXISTS public.cities;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public.businesses;
DROP TABLE IF EXISTS public.business_services;
DROP TABLE IF EXISTS public.business_images;
DROP TABLE IF EXISTS public.advertisements;
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- Name: advertisements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.advertisements (
    "Id" uuid NOT NULL,
    title_ku character varying(200) NOT NULL,
    title_kmr character varying(200) NOT NULL,
    title_de character varying(200) NOT NULL,
    title_en character varying(200) NOT NULL,
    description_ku character varying(500),
    description_kmr character varying(500),
    description_de character varying(500),
    description_en character varying(500),
    "ImageUrl" character varying(500) NOT NULL,
    "LinkUrl" character varying(500),
    "BusinessId" uuid,
    "StartDate" timestamp with time zone NOT NULL,
    "EndDate" timestamp with time zone NOT NULL,
    "IsActive" boolean DEFAULT true NOT NULL,
    "SortOrder" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


--
-- Name: business_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.business_images (
    "Id" uuid NOT NULL,
    "BusinessId" uuid NOT NULL,
    "Url" character varying(1000) NOT NULL,
    "AltText" character varying(300),
    "IsPrimary" boolean DEFAULT false NOT NULL,
    "SortOrder" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


--
-- Name: business_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.business_services (
    "Id" uuid NOT NULL,
    "BusinessId" uuid NOT NULL,
    name_ku character varying(200) NOT NULL,
    name_kmr character varying(200) NOT NULL,
    name_de character varying(200) NOT NULL,
    name_en character varying(200) NOT NULL,
    description_ku text,
    description_kmr text,
    description_de text,
    description_en text,
    "Price" numeric(10,2),
    "SortOrder" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


--
-- Name: businesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.businesses (
    "Id" uuid NOT NULL,
    name_ku character varying(200) NOT NULL,
    name_kmr character varying(200) NOT NULL,
    name_de character varying(200) NOT NULL,
    name_en character varying(200) NOT NULL,
    "Slug" character varying(250) NOT NULL,
    description_ku text NOT NULL,
    description_kmr text NOT NULL,
    description_de text NOT NULL,
    description_en text NOT NULL,
    "CategoryId" uuid NOT NULL,
    street character varying(300) NOT NULL,
    postal_code character varying(10) NOT NULL,
    city_id uuid NOT NULL,
    latitude numeric(10,7) NOT NULL,
    longitude numeric(10,7) NOT NULL,
    "Phone" character varying(20),
    "Email" character varying(200),
    "Website" character varying(500),
    opening_hours text,
    "Status" integer DEFAULT 0 NOT NULL,
    "IsVerified" boolean DEFAULT false NOT NULL,
    "OwnerId" uuid,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL,
    "CreatedBy" text,
    "UpdatedBy" text,
    "IsFeatured" boolean DEFAULT false NOT NULL,
    discount_description_de character varying(500),
    discount_description_en character varying(500),
    discount_description_kmr character varying(500),
    discount_description_ku character varying(500),
    discount_end_date timestamp with time zone,
    discount_percentage integer,
    discount_start_date timestamp with time zone
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    "Id" uuid NOT NULL,
    name_ku character varying(150) NOT NULL,
    name_kmr character varying(150) NOT NULL,
    name_de character varying(150) NOT NULL,
    name_en character varying(150) NOT NULL,
    "Slug" character varying(150) NOT NULL,
    "Icon" character varying(100),
    "SortOrder" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


--
-- Name: cities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cities (
    "Id" uuid NOT NULL,
    name_ku character varying(150) NOT NULL,
    name_kmr character varying(150) NOT NULL,
    name_de character varying(150) NOT NULL,
    name_en character varying(150) NOT NULL,
    "Slug" character varying(150) NOT NULL,
    "Latitude" numeric(10,7) NOT NULL,
    "Longitude" numeric(10,7) NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


--
-- Name: contact_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact_messages (
    "Id" uuid NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Email" character varying(200) NOT NULL,
    "Message" character varying(5000) NOT NULL,
    "IsRead" boolean DEFAULT false NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


--
-- Name: favorites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.favorites (
    "Id" uuid NOT NULL,
    "BusinessId" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


--
-- Name: menu_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menu_items (
    "Id" uuid NOT NULL,
    "BusinessId" uuid NOT NULL,
    name_ku character varying(200) NOT NULL,
    name_kmr character varying(200) NOT NULL,
    name_de character varying(200) NOT NULL,
    name_en character varying(200) NOT NULL,
    description_ku text,
    description_kmr text,
    description_de text,
    description_en text,
    "Price" numeric(10,2),
    "ImageUrl" character varying(1000),
    "SortOrder" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id uuid NOT NULL,
    token character varying(512) NOT NULL,
    user_id uuid NOT NULL,
    replaced_by_token character varying(512),
    family character varying(64) NOT NULL,
    created_by_ip character varying(45) NOT NULL,
    revoked_by_ip character varying(45),
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reviews (
    "Id" uuid NOT NULL,
    "BusinessId" uuid NOT NULL,
    "UserId" uuid NOT NULL,
    "Rating" integer NOT NULL,
    "Comment" character varying(2000),
    "IsApproved" boolean DEFAULT false NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


--
-- Name: role_claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_claims (
    "Id" integer NOT NULL,
    "RoleId" uuid NOT NULL,
    "ClaimType" text,
    "ClaimValue" text
);


--
-- Name: role_claims_Id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.role_claims ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."role_claims_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    "Id" uuid NOT NULL,
    "Name" character varying(256),
    "NormalizedName" character varying(256),
    "ConcurrencyStamp" text
);


--
-- Name: user_claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_claims (
    "Id" integer NOT NULL,
    "UserId" uuid NOT NULL,
    "ClaimType" text,
    "ClaimValue" text
);


--
-- Name: user_claims_Id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.user_claims ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."user_claims_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_logins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_logins (
    "LoginProvider" text NOT NULL,
    "ProviderKey" text NOT NULL,
    "ProviderDisplayName" text,
    "UserId" uuid NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    "UserId" uuid NOT NULL,
    "RoleId" uuid NOT NULL
);


--
-- Name: user_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_tokens (
    "UserId" uuid NOT NULL,
    "LoginProvider" text NOT NULL,
    "Name" text NOT NULL,
    "Value" text
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    "Id" uuid NOT NULL,
    "FullName" character varying(200) NOT NULL,
    "IsActive" boolean DEFAULT true NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL,
    "UserName" character varying(256),
    "NormalizedUserName" character varying(256),
    "Email" character varying(256),
    "NormalizedEmail" character varying(256),
    "EmailConfirmed" boolean NOT NULL,
    "PasswordHash" text,
    "SecurityStamp" text,
    "ConcurrencyStamp" text,
    "PhoneNumber" text,
    "PhoneNumberConfirmed" boolean NOT NULL,
    "TwoFactorEnabled" boolean NOT NULL,
    "LockoutEnd" timestamp with time zone,
    "LockoutEnabled" boolean NOT NULL,
    "AccessFailedCount" integer NOT NULL
);


--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20260404020634_InitialCreate	10.0.5
20260406012303_AddReviewsAdvertisementsFavorites	10.0.5
20260406030012_AddIsFeaturedToBusiness	10.0.5
20260408045036_AddBusinessDiscounts	10.0.5
20260408053213_AddRefreshTokens	10.0.5
\.


--
-- Data for Name: advertisements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.advertisements ("Id", title_ku, title_kmr, title_de, title_en, description_ku, description_kmr, description_de, description_en, "ImageUrl", "LinkUrl", "BusinessId", "StartDate", "EndDate", "IsActive", "SortOrder", "CreatedAt", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: business_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.business_images ("Id", "BusinessId", "Url", "AltText", "IsPrimary", "SortOrder", "CreatedAt", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: business_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.business_services ("Id", "BusinessId", name_ku, name_kmr, name_de, name_en, description_ku, description_kmr, description_de, description_en, "Price", "SortOrder", "CreatedAt", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: businesses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.businesses ("Id", name_ku, name_kmr, name_de, name_en, "Slug", description_ku, description_kmr, description_de, description_en, "CategoryId", street, postal_code, city_id, latitude, longitude, "Phone", "Email", "Website", opening_hours, "Status", "IsVerified", "OwnerId", "CreatedAt", "UpdatedAt", "CreatedBy", "UpdatedBy", "IsFeatured", discount_description_de, discount_description_en, discount_description_kmr, discount_description_ku, discount_end_date, discount_percentage, discount_start_date) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories ("Id", name_ku, name_kmr, name_de, name_en, "Slug", "Icon", "SortOrder", "CreatedAt", "UpdatedAt") FROM stdin;
d1a1b2c3-0001-0001-0001-000000000001	چێشتخانە	Xwaringeh	Restaurant	Restaurant	restaurant	material-symbols:restaurant	1	2025-01-01 00:00:00+00	2025-01-01 00:00:00+00
d1a1b2c3-0001-0001-0001-000000000002	سوپەرمارکێت	Dikana firotanê	Lebensmittelgeschäft	Grocery	grocery	material-symbols:local-grocery-store	2	2025-01-01 00:00:00+00	2025-01-01 00:00:00+00
d1a1b2c3-0001-0001-0001-000000000003	دەلاک	Berber	Friseur	Barber	barber	material-symbols:content-cut	3	2025-01-01 00:00:00+00	2025-01-01 00:00:00+00
d1a1b2c3-0001-0001-0001-000000000004	نانەوا	Firna nan	Bäckerei	Bakery	bakery	material-symbols:bakery-dining	4	2025-01-01 00:00:00+00	2025-01-01 00:00:00+00
d1a1b2c3-0001-0001-0001-000000000005	ئاژانسی گەشتوگوزار	Ajansa rêwîtiyê	Reisebüro	Travel Agency	travel-agency	material-symbols:flight	5	2025-01-01 00:00:00+00	2025-01-01 00:00:00+00
d1a1b2c3-0001-0001-0001-000000000006	دکتۆر	Doktor	Arzt	Doctor	doctor	material-symbols:medical-services	6	2025-01-01 00:00:00+00	2025-01-01 00:00:00+00
d1a1b2c3-0001-0001-0001-000000000007	پارێزەر	Parêzer	Anwalt	Lawyer	lawyer	material-symbols:gavel	7	2025-01-01 00:00:00+00	2025-01-01 00:00:00+00
d1a1b2c3-0001-0001-0001-000000000008	خانووبەرە	Xanî û milk	Immobilien	Real Estate	real-estate	material-symbols:house	8	2025-01-01 00:00:00+00	2025-01-01 00:00:00+00
d1a1b2c3-0001-0001-0001-000000000009	هی تر	Yên din	Sonstiges	Other	other	material-symbols:more-horiz	9	2025-01-01 00:00:00+00	2025-01-01 00:00:00+00
\.


--
-- Data for Name: cities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cities ("Id", name_ku, name_kmr, name_de, name_en, "Slug", "Latitude", "Longitude", "CreatedAt", "UpdatedAt") FROM stdin;
c1c1c1c1-0001-0001-0001-000000000001	کۆڵن	Köln	Köln	Cologne	koeln	50.9375000	6.9603000	2025-01-01 00:00:00+00	2025-01-01 00:00:00+00
c1c1c1c1-0001-0001-0001-000000000002	دۆسڵدۆرف	Düsseldorf	Düsseldorf	Düsseldorf	duesseldorf	51.2277000	6.7735000	2025-01-01 00:00:00+00	2025-01-01 00:00:00+00
\.


--
-- Data for Name: contact_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact_messages ("Id", "Name", "Email", "Message", "IsRead", "CreatedAt", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: favorites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.favorites ("Id", "BusinessId", "UserId", "CreatedAt", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: menu_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.menu_items ("Id", "BusinessId", name_ku, name_kmr, name_de, name_en, description_ku, description_kmr, description_de, description_en, "Price", "ImageUrl", "SortOrder", "CreatedAt", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, token, user_id, replaced_by_token, family, created_by_ip, revoked_by_ip, created_at, expires_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reviews ("Id", "BusinessId", "UserId", "Rating", "Comment", "IsApproved", "CreatedAt", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: role_claims; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_claims ("Id", "RoleId", "ClaimType", "ClaimValue") FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles ("Id", "Name", "NormalizedName", "ConcurrencyStamp") FROM stdin;
019e9500-6320-7449-a58f-9703404477a1	User	USER	18ca0545-6849-418c-b6ab-4fea9ffbdf34
019e9500-637d-72ae-bd27-30afff4ae95b	BusinessOwner	BUSINESSOWNER	368b1dc4-9d6e-40ac-bbf7-dd9825c273f6
019e9500-6381-7ab8-84a7-85d1d9255937	Moderator	MODERATOR	0126817c-175b-4014-b557-88ba1d460e5b
019e9500-6384-776a-88da-1a8b15467349	Admin	ADMIN	b99ebcf2-c47f-4895-a6da-0b9898286322
019e9500-6386-7d22-9899-0158dc06071e	SuperAdmin	SUPERADMIN	df65eff1-a077-4801-bf13-08c030aa7926
\.


--
-- Data for Name: user_claims; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_claims ("Id", "UserId", "ClaimType", "ClaimValue") FROM stdin;
\.


--
-- Data for Name: user_logins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_logins ("LoginProvider", "ProviderKey", "ProviderDisplayName", "UserId") FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles ("UserId", "RoleId") FROM stdin;
019e9500-641d-77b6-849a-ba07af408840	019e9500-6384-776a-88da-1a8b15467349
019e9500-641d-77b6-849a-ba07af408840	019e9500-6386-7d22-9899-0158dc06071e
\.


--
-- Data for Name: user_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_tokens ("UserId", "LoginProvider", "Name", "Value") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users ("Id", "FullName", "IsActive", "CreatedAt", "UpdatedAt", "UserName", "NormalizedUserName", "Email", "NormalizedEmail", "EmailConfirmed", "PasswordHash", "SecurityStamp", "ConcurrencyStamp", "PhoneNumber", "PhoneNumberConfirmed", "TwoFactorEnabled", "LockoutEnd", "LockoutEnabled", "AccessFailedCount") FROM stdin;
019e9500-641d-77b6-849a-ba07af408840	Aram Hossaini	t	2026-06-04 23:38:11.2258+00	2026-06-04 23:38:11.2258+00	admin@kurdmap.de	ADMIN@KURDMAP.DE	admin@kurdmap.de	ADMIN@KURDMAP.DE	t	AQAAAAIAAYagAAAAEBab3yPwaUwOgWa6bxi348FqrhAoo4WUQbY5FtXtnsZdnWNL0gJUD3EqVPUk3fJNRA==	543HMNGIXVVX6FLPMGQAIYLROPYE5JMN	ac6242ff-2e31-4572-bad6-1e548f0925de	\N	f	f	\N	t	0
\.


--
-- Name: role_claims_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."role_claims_Id_seq"', 1, false);


--
-- Name: user_claims_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."user_claims_Id_seq"', 1, false);


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: advertisements PK_advertisements; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.advertisements
    ADD CONSTRAINT "PK_advertisements" PRIMARY KEY ("Id");


--
-- Name: business_images PK_business_images; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_images
    ADD CONSTRAINT "PK_business_images" PRIMARY KEY ("Id");


--
-- Name: business_services PK_business_services; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_services
    ADD CONSTRAINT "PK_business_services" PRIMARY KEY ("Id");


--
-- Name: businesses PK_businesses; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.businesses
    ADD CONSTRAINT "PK_businesses" PRIMARY KEY ("Id");


--
-- Name: categories PK_categories; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "PK_categories" PRIMARY KEY ("Id");


--
-- Name: cities PK_cities; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT "PK_cities" PRIMARY KEY ("Id");


--
-- Name: contact_messages PK_contact_messages; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact_messages
    ADD CONSTRAINT "PK_contact_messages" PRIMARY KEY ("Id");


--
-- Name: favorites PK_favorites; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT "PK_favorites" PRIMARY KEY ("Id");


--
-- Name: menu_items PK_menu_items; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT "PK_menu_items" PRIMARY KEY ("Id");


--
-- Name: refresh_tokens PK_refresh_tokens; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT "PK_refresh_tokens" PRIMARY KEY (id);


--
-- Name: reviews PK_reviews; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT "PK_reviews" PRIMARY KEY ("Id");


--
-- Name: role_claims PK_role_claims; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_claims
    ADD CONSTRAINT "PK_role_claims" PRIMARY KEY ("Id");


--
-- Name: roles PK_roles; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT "PK_roles" PRIMARY KEY ("Id");


--
-- Name: user_claims PK_user_claims; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_claims
    ADD CONSTRAINT "PK_user_claims" PRIMARY KEY ("Id");


--
-- Name: user_logins PK_user_logins; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_logins
    ADD CONSTRAINT "PK_user_logins" PRIMARY KEY ("LoginProvider", "ProviderKey");


--
-- Name: user_roles PK_user_roles; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "PK_user_roles" PRIMARY KEY ("UserId", "RoleId");


--
-- Name: user_tokens PK_user_tokens; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_tokens
    ADD CONSTRAINT "PK_user_tokens" PRIMARY KEY ("UserId", "LoginProvider", "Name");


--
-- Name: users PK_users; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_users" PRIMARY KEY ("Id");


--
-- Name: EmailIndex; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "EmailIndex" ON public.users USING btree ("NormalizedEmail");


--
-- Name: IX_contact_messages_CreatedAt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_contact_messages_CreatedAt" ON public.contact_messages USING btree ("CreatedAt");


--
-- Name: IX_favorites_BusinessId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_favorites_BusinessId_UserId" ON public.favorites USING btree ("BusinessId", "UserId");


--
-- Name: IX_favorites_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_favorites_UserId" ON public.favorites USING btree ("UserId");


--
-- Name: IX_reviews_BusinessId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_reviews_BusinessId" ON public.reviews USING btree ("BusinessId");


--
-- Name: IX_reviews_BusinessId_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IX_reviews_BusinessId_UserId" ON public.reviews USING btree ("BusinessId", "UserId");


--
-- Name: IX_role_claims_RoleId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_role_claims_RoleId" ON public.role_claims USING btree ("RoleId");


--
-- Name: IX_user_claims_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_user_claims_UserId" ON public.user_claims USING btree ("UserId");


--
-- Name: IX_user_logins_UserId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_user_logins_UserId" ON public.user_logins USING btree ("UserId");


--
-- Name: IX_user_roles_RoleId; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IX_user_roles_RoleId" ON public.user_roles USING btree ("RoleId");


--
-- Name: RoleNameIndex; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "RoleNameIndex" ON public.roles USING btree ("NormalizedName");


--
-- Name: UserNameIndex; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "UserNameIndex" ON public.users USING btree ("NormalizedUserName");


--
-- Name: ix_advertisements_active_dates; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_advertisements_active_dates ON public.advertisements USING btree ("IsActive", "StartDate", "EndDate");


--
-- Name: ix_business_images_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_business_images_sort ON public.business_images USING btree ("BusinessId", "SortOrder");


--
-- Name: ix_business_services_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_business_services_sort ON public.business_services USING btree ("BusinessId", "SortOrder");


--
-- Name: ix_businesses_city_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_businesses_city_category ON public.businesses USING btree ("CategoryId");


--
-- Name: ix_businesses_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_businesses_owner ON public.businesses USING btree ("OwnerId");


--
-- Name: ix_businesses_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_businesses_slug ON public.businesses USING btree ("Slug");


--
-- Name: ix_businesses_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_businesses_status ON public.businesses USING btree ("Status");


--
-- Name: ix_categories_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_categories_slug ON public.categories USING btree ("Slug");


--
-- Name: ix_categories_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_categories_sort ON public.categories USING btree ("SortOrder");


--
-- Name: ix_cities_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_cities_slug ON public.cities USING btree ("Slug");


--
-- Name: ix_menu_items_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_menu_items_sort ON public.menu_items USING btree ("BusinessId", "SortOrder");


--
-- Name: ix_refresh_tokens_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refresh_tokens_expires_at ON public.refresh_tokens USING btree (expires_at);


--
-- Name: ix_refresh_tokens_family; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refresh_tokens_family ON public.refresh_tokens USING btree (family);


--
-- Name: ix_refresh_tokens_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_refresh_tokens_token ON public.refresh_tokens USING btree (token);


--
-- Name: ix_refresh_tokens_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refresh_tokens_user_id ON public.refresh_tokens USING btree (user_id);


--
-- Name: business_images FK_business_images_businesses_BusinessId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_images
    ADD CONSTRAINT "FK_business_images_businesses_BusinessId" FOREIGN KEY ("BusinessId") REFERENCES public.businesses("Id") ON DELETE CASCADE;


--
-- Name: business_services FK_business_services_businesses_BusinessId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.business_services
    ADD CONSTRAINT "FK_business_services_businesses_BusinessId" FOREIGN KEY ("BusinessId") REFERENCES public.businesses("Id") ON DELETE CASCADE;


--
-- Name: businesses FK_businesses_categories_CategoryId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.businesses
    ADD CONSTRAINT "FK_businesses_categories_CategoryId" FOREIGN KEY ("CategoryId") REFERENCES public.categories("Id") ON DELETE RESTRICT;


--
-- Name: businesses FK_businesses_users_OwnerId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.businesses
    ADD CONSTRAINT "FK_businesses_users_OwnerId" FOREIGN KEY ("OwnerId") REFERENCES public.users("Id");


--
-- Name: menu_items FK_menu_items_businesses_BusinessId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT "FK_menu_items_businesses_BusinessId" FOREIGN KEY ("BusinessId") REFERENCES public.businesses("Id") ON DELETE CASCADE;


--
-- Name: refresh_tokens FK_refresh_tokens_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT "FK_refresh_tokens_users_user_id" FOREIGN KEY (user_id) REFERENCES public.users("Id") ON DELETE CASCADE;


--
-- Name: role_claims FK_role_claims_roles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_claims
    ADD CONSTRAINT "FK_role_claims_roles_RoleId" FOREIGN KEY ("RoleId") REFERENCES public.roles("Id") ON DELETE CASCADE;


--
-- Name: user_claims FK_user_claims_users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_claims
    ADD CONSTRAINT "FK_user_claims_users_UserId" FOREIGN KEY ("UserId") REFERENCES public.users("Id") ON DELETE CASCADE;


--
-- Name: user_logins FK_user_logins_users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_logins
    ADD CONSTRAINT "FK_user_logins_users_UserId" FOREIGN KEY ("UserId") REFERENCES public.users("Id") ON DELETE CASCADE;


--
-- Name: user_roles FK_user_roles_roles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "FK_user_roles_roles_RoleId" FOREIGN KEY ("RoleId") REFERENCES public.roles("Id") ON DELETE CASCADE;


--
-- Name: user_roles FK_user_roles_users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "FK_user_roles_users_UserId" FOREIGN KEY ("UserId") REFERENCES public.users("Id") ON DELETE CASCADE;


--
-- Name: user_tokens FK_user_tokens_users_UserId; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_tokens
    ADD CONSTRAINT "FK_user_tokens_users_UserId" FOREIGN KEY ("UserId") REFERENCES public.users("Id") ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict EPAUHVd6cdIyngCzOwRiTBGNdyj0lhAkEgNnZlj80gjNvwzlRCaseJeFhCOJpFk

